/// Flyer Chat Image Message package. Provides a widget for image messages.
library;

export 'src/flyer_chat_image_message.dart';
export 'src/get_image_dimensions.dart';
