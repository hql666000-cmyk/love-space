## 0.0.13

 - **FEAT**: update deps - requires min dart 3.8 and flutter 3.32 ([#871](https://github.com/flyerhq/flutter_chat_ui/issues/871)). ([588b34bd](https://github.com/flyerhq/flutter_chat_ui/commit/588b34bd398900c8f25ee69c574d1e35391af1d1))

## 0.0.12+2

 - **FIX**: update LICENSE. ([209a1292](https://github.com/flyerhq/flutter_chat_ui/commit/209a129297ebe7fd202e41273c9c0ddd52b8b983))

## 0.0.12+1

 - **FIX**: update dependencies. ([a8ff8b57](https://github.com/flyerhq/flutter_chat_ui/commit/a8ff8b573a25146d5c78b1014c9caa3126d1de40))

## 0.0.12

- Version bump to match other packages

## 0.0.11

- Version bump to match other packages

## 0.0.10

- Version bump to match other packages

## 0.0.9

- Version bump to match other packages

## 0.0.8

- Version bump to match other packages

## 0.0.7

- Require Flutter 3.29 and Dart 3.7

## 0.0.6

- Version bump to match other packages

## 0.0.5

- Version bump to match other packages

## 0.0.4

- Version bump to match other packages

## 0.0.3

- Version bump to match other packages

## 0.0.1

- Initial release
