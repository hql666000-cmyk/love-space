/// Enum controlling the position of the link preview widget.
enum LinkPreviewPosition { top, bottom, none }
